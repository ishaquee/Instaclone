module.exports={
    MONGODB_URI: "mongodb+srv://user:SaJ0WCOfQ6U0EfHf@cluster0.rdyyo.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    JWT_SECRECT: "djosdhfosdhnwuydhhwjwijeiwjdijwijxiwifhi"
}