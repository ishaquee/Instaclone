import React, { createContext , useContext, useEffect, useReducer} from "react";
import { BrowserRouter, Route, Routes , useNavigate} from 'react-router-dom';
import Navbar from "./components/Navbar";
import Home from './Pages/Home';
import Login from './Pages/Login';
import Signup from './Pages/Signup';
import Profile from './Pages/Profile';
import CreatePost from "./Pages/createpost";
import { reducer , initialState} from './reducers/userReducers'
import OtherUserProfile from "./Pages/OtherUserProfile";
import Postsfromfollowing from "./Pages/Postsfromfollowing";
import Footer from "./components/footer";
import Reset from "./Pages/Reset";
import Newpassword from "./Pages/Newpassword";
import SearchUser from "./Pages/SearchUser";
import {  useLocation } from 'react-router-dom';
import Settings from "./Pages/Settings";
import Notifications from "./Pages/Notifications";
import Updatepass from "./Pages/Updatepass";
export const UserContext = createContext();


const CustomRouting = () =>{
  const navicate = useNavigate();
  const location = useLocation();

  const {state,dispatch} = useContext(UserContext);
  useEffect(()=> {
    const userinfo = JSON.parse(localStorage.getItem("userinfo"));
    if(userinfo)
    {
      dispatch({type: "USER" , payload : userinfo})
      navicate('/')
    }
    else{
      if(!location.pathname.startsWith('/reset'))
        navicate('/login')
    }

  },[]);
  return (
      <Routes>
        <Route  path="/"  element={<Home />} />
        <Route  path="/login"  element={<Login />} />
        <Route  path="/signup"  element={<Signup />} />
        <Route exact path="/profile"  element={<Profile />} />
        <Route  path="/profile/:userId"  element={<OtherUserProfile />} />
        <Route path="/Postsfromfollowing"  element={ <Postsfromfollowing/> } />
        <Route path="/create-post"  element={<CreatePost />} />
        <Route path="/reset-password"  element={<Reset />} />
        <Route path="/reset/:token"  element={<Newpassword />} />
        <Route  path="/setting"  element={<Settings />} />
        <Route  path="/Search"  element={<SearchUser />} />
        <Route  path="/Notifications"  element={<Notifications />} />
        <Route  path="/Updatepass"  element={<Updatepass />} />



        {/* catch-all 404 page */}
         {/* <Route path="*" element={<Page404 />} />  */}
      </Routes>
  )
}

function App() {

  const [state,dispatch] = useReducer(reducer,initialState);
  return (
    
    <UserContext.Provider value={{state : state , dispatch : dispatch}}>
      <BrowserRouter>
      <Navbar/>
      <CustomRouting/> 
      { state ? <Footer/> : "" }
    </BrowserRouter>
    </UserContext.Provider>
   
  );
}

export default App;
