import React,{useEffect,useState,useContext} from 'react'
import './profile.css'
import {UserContext} from '../App';
import M from 'materialize-css'
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import {Rings, TailSpin } from  'react-loader-spinner';
import {FiSettings} from 'react-icons/fi'
import { Link ,useNavigate } from 'react-router-dom';
import Favorite from '@material-ui/icons/Favorite';



function Profile() {
    const {state,dispatch} = useContext(UserContext);
    const [myposts,setMyposts] = useState([]);
    const [image,setImage] = useState("")
    const [loader,setLoader] = useState(false);
    const [myprofile, setmyProfile] = useState();

    const  navigate = useNavigate();

    useEffect(() => {
        fetch(`https://instabackend22.herokuapp.com/user/${state._id}`, {
            method: "get",
            headers: {
                "Authorization": "Bearer " + localStorage.getItem("token")
            }
        })
            .then(response => response.json())
            .then(function (data) {
                console.log(data);
                setmyProfile(data);
            }).catch(error => {
                console.log(error);
            });
    }, []);

    useEffect(()=>{
        if(image){
         const data = new FormData()
         data.append("file",image)
         data.append("upload_preset","instaclone-app")
         data.append("cloud_name","instaclone2022")
         fetch("https://api.cloudinary.com/v1_1/instaclone2022/image/upload",{
             method:"post",
             body:data
          })
        .then(res=> res.json())
         .then(data=>{
            fetch('https://instabackend22.herokuapp.com/updatepic',{
                method:"put",
                headers:{
                    "Content-Type":"application/json",
                    "Authorization":"Bearer "+localStorage.getItem("token")
                },
                body:JSON.stringify({
                    url:data.url
                })
            })
         .then(res=>res.json())
            .then(result=>{
                setLoader(false)
                console.log("result-->" + result)
                localStorage.setItem("userinfo",JSON.stringify({...state,profilePicUrl:result.profilePicUrl}))
                dispatch({type:"UPDATEPIC",payload:result.profilePicUrl})
                //window.location.reload()
            })
         })
         .catch(err=>{
             console.log(err)
         })
        }
     },[image])

    useEffect(() => {      
            fetch("https://instabackend22.herokuapp.com/myposts",{
                method: "get",
                headers:
                {
                    "Authorization": "Bearer "+ localStorage.getItem("token")
                }
            })
            .then(response => response.json())
            .then(function(data){
                setMyposts(data.posts)
                console.log(data.posts)
            }).catch(error => {
                console.log(error);
            })
        }
    ,[]);

    const updatePhoto = (file)=>{
        setLoader(true)
        setImage(file)
    }

    return (
        <div style={{maxWidth:"550px",margin:"0px auto"}}>
        <div style={{
           margin:"18px 0px",
            borderBottom:"2px solid grey"
        }}>

      
        <div style={{
            display:"flex",
            justifyContent:"space-around",
           
        }}>
            <div>
                <img style={{width:"160px",height:"160px",borderRadius:"80px"}}
                src={state?state.profilePicUrl:"loading"}
                />
              
            </div>
            <div >
            <i style={{ fontSize:'30px',display:'inline',color:'darkblue',cursor:'pointer',float:'right'}} onClick={() =>navigate('/setting')} ><FiSettings/> </i>

                <h4> <span style={{fontSize:'20px'}}>{state?state.fullName:"loading"}</span>  
</h4>
<h5 className='username'>{state?state.username:"loading"} 
</h5>

                {/* <h5>{state?state.email:"loading"}</h5> */}
                <div class="profile-stats">

<ul style={{display:"flex",justifyContent:'space-around'}}>
    <li style={{marginRight:'5px',fontWeight:'600',fontSize:'15px'}}><span class="profile-stat-count">{myposts.length} </span> <span style={{fontWeight:'lighter',fontSize:'10px'}}>posts </span></li>
    <li style={{marginRight:'5px',fontWeight:'600',fontSize:'15px'}}><span class="profile-stat-count">{myprofile  ? myprofile.user.followers.length : 0}</span> <span style={{fontWeight:'lighter',fontSize:'10px'}}> followers  </span> </li>
    <li style={{marginRight:'5px',fontWeight:'600',fontSize:'15px'}}><span class="profile-stat-count">{myprofile  ? myprofile.user.following.length : 0}</span> <span style={{fontWeight:'lighter',fontSize:'10px'}} > following </span> </li>
</ul>

</div>

            </div>
        </div>
         </div>      
         <div className='Posts'>
                {
                    myposts.length > 0 ? 
                    myposts.map((mypost)=>{
                        return(             
                    <img className='post' src= {mypost.image} alt= {mypost.title} key={mypost._id} title={ mypost.likes.length+ " likes ❤️ "} />  
                           
                        )   })
                        : <div>  
                        <h5 style={{
                            display:"flex",
                            alignItems:"center",
                            justifyContent:"center"
                        }} >  don't have Any Post </h5> 
                        </div> 
                }
        </div>
    </div>
)
}


export default Profile