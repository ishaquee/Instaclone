import React,{useState,useEffect,useContext} from 'react';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Favorite from '@material-ui/icons/Favorite';
import FavoriteBorder from '@material-ui/icons/FavoriteBorder';
import './Home.css';
import {UserContext} from '../App';
import {Link} from 'react-router-dom'
import {IoHeartCircleOutline,IoHeartCircleSharp  } from 'react-icons/io5';
import {BsHeart } from 'react-icons/bs';

function Home() {


    
    const [posts,setPosts] = useState([]);
    const [comment,setcomment] = useState('');
    const {state,dispatch} = useContext(UserContext);

    const postcomment = (event,postId) => {
        setcomment(event);
        submitcomment(comment,postId)
        setcomment('')
    }
    const timeconverter= (timestamp)=>
    {
        const d = new Date( timestamp );
        const date = d.getHours() + ":" + d.getMinutes() + ", " + d.toDateString();
        return date
    }
    useEffect(() => {
        if(posts){
            fetch("https://instabackend22.herokuapp.com/posts",{
                method: "get",
                headers:
                {
                    "Authorization": "Bearer "+ localStorage.getItem("token")
                }
            })
            .then(response => response.json())
            .then(function(data){
                setPosts(data.posts)
            }).catch(error => {
                console.log(error);
            })
        }
    },[]);

    const likeunlike = (postId,url) => {
        fetch(url,{
            method: "put",
            headers:
            {
                "Content-Type": "application/json",
                "Authorization": "Bearer "+ localStorage.getItem("token")
            },
            body:
           JSON.stringify({postId: postId})
            
        })
        .then(response => response.json())
        .then(function(updatedpost){
            const newPostarr = posts.map((oldpost)=>{
                if(oldpost._id == updatedpost._id)
                {
                    return updatedpost;
                }
                else
                {
                    return oldpost;
                }
            });
            setPosts(newPostarr)
        }).catch(error => {
            console.log(error);
        })
    }


    const deletePost = (postId) => {
        fetch( `https://instabackend22.herokuapp.com/delete/${postId}`,{
            method: "delete",
            headers:
            {
                "Authorization": "Bearer "+ localStorage.getItem("token")
            }
        })
        .then(response => response.json())
        .then(function(deletedpost){
            const newPostarr = posts.filter((oldpost)=>{
                return (oldpost._id != deletedpost.result._id)
                
            });
            setPosts(newPostarr)
        }).catch(error => {
            console.log(error);
        })
    }


    const submitcomment = (event,postId) => {
        event.preventDefault(); 
        const commentText = event.target[0].value;
        fetch('https://instabackend22.herokuapp.com/comment',{
            method: "put",
            headers:
            {
                "Content-Type": "application/json",
                "Authorization": "Bearer "+ localStorage.getItem("token")
            },
            body:
           JSON.stringify({commentText: commentText , postId : postId})
            
        })
        .then(response => response.json())
        .then(function(updatedpost){
            const newPostarr = posts.map((oldpost)=>{
                if(oldpost._id == updatedpost._id)
                {
                    return updatedpost;
                }
                else
                {
                    return oldpost;
                }
            });
            setPosts(newPostarr)
        }).catch(error => {
            console.log(error);
        })
    }
    
    return (
        <div className='home-container'>
            {          
               posts.map((post)=>{
                   return( 
               <div className='card1 home-card' key={post._id} >
               <h5 style={{padding : "1px",display:'inline',marginLeft:'1px'}}>  
               <img className='image-icon' style={{width : "25px", height: "25px",borderRadius:"35px",marginRight:"10px",marginTop:'2px'}} src= { post ? post.author.profilePicUrl : "Loading" }/>  
               <span className='fullname1' style={{textDecoration:'none',fontSize:'20px',marginTop:'0px'}}>
               <Link to= {post.author._id !== state._id ? "/profile/" + (post.author._id) : "/profile"} style={{textDecoration:'none'}}> 
               {post.author.fullName}  </Link></span>
               
               {
                   post.author._id == state._id && <i onClick={()=> deletePost(post._id)} className="material-icons" style={{color: "gray",float :"right", cursor: "pointer" , width: "35px"}} > delete_forever </i>
               }
               </h5>
               <div className='card-image'>
               <img className='post-image' style={{cursor:"pointer"}} onDoubleClick= { ()=> post.likes.includes(state._id)  ? likeunlike(post._id,'https://instabackend22.herokuapp.com/unlike') : likeunlike(post._id,'https://instabackend22.herokuapp.com/like') } src= {post.image} alt='alt' />
               </div>
               
               <div className='card-content'>
               
               <div className='likes'>

                   {/* {
                       post.likes.includes(state._id)  ?  <i onClick={()=> likeunlike(post._id,'https://instabackend22.herokuapp.com/unlike')} className="material-icons" style={{color: "green",marginRight: "1px" , cursor: "pointer" , width: "15px"}} ><Favorite/></i>
                       : <i onClick={()=> likeunlike(post._id,'https://instabackend22.herokuapp.com/like')}className="material-icons" style={{color: "black",marginRight: "1px",cursor:"pointer"}} ><FavoriteBorder /></i>
                   } */}
                   {
                       post.likes.includes(state._id)  ? <i onClick={()=> likeunlike(post._id,'https://instabackend22.herokuapp.com/unlike')} style={{color: "royalblue",marginRight: "10px" , cursor: "pointer" , width: "15px",fontSize:'30px'}} ><IoHeartCircleOutline/></i>
                       : <i onClick={()=> likeunlike(post._id,'https://instabackend22.herokuapp.com/like')} style={{color: "royalblue",marginRight: "10px",cursor:"pointer",width:'15px',fontSize:'30px'}} ><IoHeartCircleSharp /></i>
                   }
                  <h6 style={{marginTop:'0px'}}> { post.likes.length > 0 ? post.likes.length : "0"  }  likes </h6>
                                 </div>
                   
                   <h5 style={{marginTop:'-5px'}} > {post.title} </h5>
                   <p> {post.body} </p>

                   {
                       post.comments.length > 0 ? <h6 style={{fontWeight: "500",marginTop:'-15px'}}> All Comments </h6> : " "
                   }
                   <div id='columnBox'> 
                   {
                       post.comments.map((comment)=>{
                           return(
                               <div className='comment'>
                              <h6 key={post._id}> 
                                <span style={{marginRight: "10px" , fontWeight: "bold"}} > {comment.CommentedBy.fullName} </span>
                               <span > {comment.CommentText} </span>
                             </h6>
                             </div>
                           )
                       })
                   }
                   </div>

                   <form onSubmit={(event)=> {submitcomment(event,post._id)}}>
                   <input type="text" placeholder='comments' />

                   </form>
                   <h6 style={{color: "gray", cursor: "pointer",fontSize:'10px',float:'right',margin:"-10px"}} className='' > {
                   timeconverter(post.createdAt)
               } </h6>
               </div>
           </div>          
             )
            })
            }
            </div>
           
    )
}

export default Home