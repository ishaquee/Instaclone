import React, { useEffect, useState, useContext } from 'react'
import { Link ,useNavigate } from 'react-router-dom';
import './navbar.css'
import {UserContext} from '../App'
import {FiInstagram} from 'react-icons/fi'
import {MdNotificationsNone} from 'react-icons/md'
import {MdNotificationsActive} from 'react-icons/md'
import Badge from '@mui/material/Badge';
import MailIcon from '@mui/icons-material/Mail';

const Navbar = () =>  {
  
  const {state,dispatch} = useContext(UserContext);
  const  navigate = useNavigate();
  const [request,setRequest] = useState([])

  
  useEffect(()=>{
    fetch('https://instabackend22.herokuapp.com/getallrequest', {
            method: "get",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("token")
            }
        })
            .then(res => res.json())
            .then(function (data) {
                setRequest(data.posts[0].Requested)
            }).catch(error => {
                console.log(error);
            });
  },[state])

  const logout = ()=>{
    localStorage.clear();
    dispatch({type: "LOGOUT"})
    navigate('/login')
  }
  const navList = () => {
    if(state)
    {
      return[
        <li key="121" style={{float:'right'}} >
        <Link to='/Notifications' > {request ? request.length > 0  ? <Badge badgeContent={request.length} color='primary'>
      <MailIcon color='success' />
    </Badge>   : <Badge badgeContent={0} color='primary'>
      <MailIcon color='action' />
    </Badge>  : ''}  </Link>
        </li> 
            ]
    }
    else{
      return[
        <div className='someone'>
        <li key="877" ><Link to="/Login" className='right'>Login</Link></li>
        <li key="0769"><Link to="/Signup" className='right'>Signup</Link></li>
        </div>
      ]
    }
  }
  
    return (    
  <nav>
    <div className="navbar navbar-expand-lg white-bg" style={{position:"fixed",width:"100%",zIndex:"999",height:"9%"}}>
      <Link to={state ? "/" : "/login"} className="brand-logo center" style={{textDecoration:"none",display:"inline"}} > <li style={{textDecoration:"none",listStyle:"none" }} > <span className='instax'> Instaclone </span>  <span  style={{fontSize:'20px'}}><FiInstagram /></span> </li></Link>
      <ul className='someone'>
        {navList()}
      </ul>
    </div>
    
  </nav>
    )
}

export default Navbar;
