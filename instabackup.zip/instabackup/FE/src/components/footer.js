import React, {useContext,useRef,useEffect,useState} from 'react'
import { Link ,useNavigate } from 'react-router-dom';
import './navbar.css'
import {UserContext} from '../App'
import { BsPlusSquareFill } from "react-icons/bs";
import {CgProfile} from 'react-icons/cg';
import {RiHomeHeartFill} from 'react-icons/ri';
import {RiUserFollowLine} from 'react-icons/ri';
import {BiSearch} from 'react-icons/bi'
import M from 'materialize-css'

const Footer = () =>  {
  const  searchModal = useRef(null)
    const [search,setSearch] = useState('')
    const [userDetails,setUserDetails] = useState([])
  const {state,dispatch} = useContext(UserContext);
  const  navigate = useNavigate();

  useEffect(()=>{
    M.Modal.init(searchModal.current)
},[])

  const navList = () => {
    if(state)
    {
      return[
        <li key="222"><Link to="/"><RiHomeHeartFill style={{
          marginTop:'15px',
          fontSize:'30px',
         }}/></Link></li>,

         <li key="2292"><Link to="/search" ><BiSearch style={{
          marginTop:'15px',
          fontSize:'35px',
         }}/></Link></li>,
         <li key="11111" > <Link to='/create-post'><BsPlusSquareFill 
         style={{
          marginTop:'15px',
          fontSize:'30px',
         }} /></Link> </li>,
        <li key="2212"><Link to="/Postsfromfollowing"><RiUserFollowLine style={{
          marginTop:'15px',
          fontSize:'30px',
         }}/></Link></li>,
        <li  key="2212122"><Link to="/Profile"><CgProfile style={{
          marginTop:'15px',
          fontSize:'35px',
         }}/></Link></li>
        
      ]
    }
  }
  const fetchUsers = (query)=>{
    setSearch(query)
    fetch('https://instabackend22.herokuapp.com/search-users',{
      method:"post",
      headers:{
        "Content-Type":"application/json"
      },
      body:JSON.stringify({
        query
      })
    }).then(res=>res.json())
    .then(results=>{
      setUserDetails(results.user)
    })
 }
    return (    
  <nav className='navbar-bottom'>
    <div className="white bottom" >
      <ul id="nav-mobile" className="right">
    {navList()}
      </ul>
      <div id="modal1" class="modal" ref={searchModal} style={{color:"black"}}>
          <div className="modal-content">
          <input
            type="text"
            placeholder="search users"
            value={search}
            onChange={(e)=>fetchUsers(e.target.value)}
            />
             <ul className="collection">
               {userDetails.map(item=>{
                 return <Link to={item._id !== state._id ? "/profile/"+item._id:'/profile'} onClick={()=>{
                   M.Modal.getInstance(searchModal.current).close()
                   setSearch('')
                 }}><li className="collection-item"style={{margin:"1%",alignItems:'flex-start',display:'flex'}}>{item.email}</li></Link> 
               })}
               
              </ul>
          </div>
          <div className="modal-footer">
            <button className="modal-close waves-effect waves-green btn-flat" onClick={()=>setSearch('')}>close</button>
          </div>
          </div>
    </div>
  </nav>
    )
}

export default Footer;
